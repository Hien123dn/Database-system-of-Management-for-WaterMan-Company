﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nhom11
{
    public partial class Ban : Form
    {
        string sCon = "Data Source=LAPTOP-PIDDRNJT\\SQLEXPRESS;Initial Catalog=Nhom11_QLBH;Integrated Security=True;Encrypt=False";
        public Ban()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void Ban_Load(object sender, EventArgs e)
        {
            LoadData(); 

        }
        private void LoadData(string keyword = "")
        {
            // Truy vấn SQL chỉ lấy các cột của bảng BAN
            string query = "SELECT * FROM BAN"; 
            // Nếu có từ khóa tìm kiếm, thêm điều kiện lọc
            if (!string.IsNullOrEmpty(keyword))
            {
                query += " WHERE MaBH LIKE @keyword OR MaNMH LIKE @keyword";
            }

            using (SqlConnection con = new SqlConnection(sCon)) // sCon là chuỗi kết nối
            {
                try
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(query, con);

                    // Thêm tham số nếu có từ khóa
                    if (!string.IsNullOrEmpty(keyword))
                    {
                        adapter.SelectCommand.Parameters.AddWithValue("@keyword", "%" + keyword + "%");
                    }

                    // Khởi tạo DataSet và điền dữ liệu vào bảng "BAN"
                    DataSet ds = new DataSet();
                    adapter.Fill(ds, "BAN");

                    // Hiển thị dữ liệu trong DataGridView
                    dataGridView1.DataSource = ds.Tables["BAN"];
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                catch (Exception ex)
                {
                    // Hiển thị thông báo lỗi nếu xảy ra lỗi
                    MessageBox.Show($"Lỗi khi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Items newForm = new Items();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Customers newForm = new Customers();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            DonViNhap newForm = new DonViNhap();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            Nhap newForm = new Nhap();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            Billing newForm = new Billing();
            newForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
           
          
            
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
