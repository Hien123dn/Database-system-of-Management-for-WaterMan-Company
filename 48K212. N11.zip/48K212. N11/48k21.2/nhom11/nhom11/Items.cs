﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace nhom11
{
    public partial class Items : Form
    {
        string Scon = "Data Source=LAPTOP-PIDDRNJT\\SQLEXPRESS;Initial Catalog=Nhom11_QLBH;Integrated Security=True;Encrypt=False";
        public Items()
        {
            InitializeComponent();
        }
        private void Hàng_hóa_Load(object sender, EventArgs e)
        {
            LoadData(); 
        }
        private void LoadData(string keyword = "")
        {
            string query = "SELECT * FROM HangHoa";
            if (!string.IsNullOrEmpty(keyword))
            {
                query += " WHERE MaHH LIKE @keyword OR TenHH LIKE @keyword OR DVT LIKE @keyword";
            }

            using (SqlConnection con = new SqlConnection(Scon))
            {
                try
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                    if (!string.IsNullOrEmpty(keyword))
                    {
                        adapter.SelectCommand.Parameters.AddWithValue("@keyword", "%" + keyword + "%");
                    }

                    DataSet ds = new DataSet();
                    adapter.Fill(ds, "HangHoa");
                    dataGridView2.DataSource = ds.Tables["HangHoa"];
                    dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Customers newForm = new Customers();
            newForm.Show();
            this.Hide();
        }

       

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem2_Click_1(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Items newForm = new Items();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem2_Click_2(object sender, EventArgs e)
        {
            Customers newForm = new Customers();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            DonViNhap newForm = new DonViNhap();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            Ban newForm = new Ban();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            Nhap newForm = new Nhap();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            Billing newForm = new Billing();
            newForm.Show();
            this.Hide();
        }
    }
}
