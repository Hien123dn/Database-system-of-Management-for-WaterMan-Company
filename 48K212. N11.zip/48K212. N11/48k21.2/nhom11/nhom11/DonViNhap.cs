﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace nhom11
{
    public partial class DonViNhap : Form
    {
        string sCon = "Data Source=LAPTOP-PIDDRNJT\\SQLEXPRESS;Initial Catalog=Nhom11_QLBH;Integrated Security=True;Encrypt=False";
        public DonViNhap()
        {
            InitializeComponent();
        }

        private void DonViNhap_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData(string keyword = "")
        {
            string query = "SELECT * FROM DonViNhap";
            if (!string.IsNullOrEmpty(keyword))
            {
                query += " WHERE MaDVN LIKE @keyword OR TenDVN LIKE @keyword OR STK LIKE @keyword OR SDT LIKE @keyword OR DiachiNH LIKE @keyword";
            }

            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                    if (!string.IsNullOrEmpty(keyword))
                    {
                        adapter.SelectCommand.Parameters.AddWithValue("@keyword", "%" + keyword + "%");
                    }

                    DataSet ds = new DataSet();
                    adapter.Fill(ds, "DonViNhap");
                    dataGridView2.DataSource = ds.Tables["DonViNhap"];
                    dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB");
            }
            string sQuery = "Select * from DonViNhap";
            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();
            adapter.Fill(ds, "DonViNhap");

      
        }

        private void nhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }


        private void toolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            Items newForm = new Items();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem2_Click_1(object sender, EventArgs e)
        {
            Customers newForm = new Customers();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem4_Click_1(object sender, EventArgs e)
        {
            Ban newForm = new Ban();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem5_Click_1(object sender, EventArgs e)
        {
            Nhap newForm = new Nhap();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem6_Click_1(object sender, EventArgs e)
        {
            Billing newForm = new Billing();
            newForm.Show();
            this.Hide();
        }
    }
}
