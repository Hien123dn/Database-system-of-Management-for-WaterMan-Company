﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace nhom11
{
    public partial class Nhap : Form
    {
        string sCon = "Data Source=LAPTOP-PIDDRNJT\\SQLEXPRESS;Initial Catalog=Nhom11_QLBH;Integrated Security=True;Encrypt=False";
        public Nhap()
        {
            InitializeComponent();
        }

        private void Nhap_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData(string keyword = "")
        {
            string query = "SELECT * FROM Nhap";
            if (!string.IsNullOrEmpty(keyword))
            {
                query += " WHERE MaNH LIKE @keyword OR MaDVN LIKE @keyword";
            }

            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                    if (!string.IsNullOrEmpty(keyword))
                    {
                        adapter.SelectCommand.Parameters.AddWithValue("@keyword", "%" + keyword + "%");
                    }

                    DataSet ds = new DataSet();
                    adapter.Fill(ds, "Nhap");
                    dataGridView2.DataSource = ds.Tables["Nhap"];
                    dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void toolStripMenuItem2_Click_1(object sender, EventArgs e)
        {
            Customers newForm = new Customers();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            Items newForm = new Items();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem3_Click_1(object sender, EventArgs e)
        {
            DonViNhap newForm = new DonViNhap();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem4_Click_1(object sender, EventArgs e)
        {
            Ban newForm = new Ban();
            newForm.Show();
            this.Hide();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripMenuItem6_Click_1(object sender, EventArgs e)
        {
            Billing newForm = new Billing();
            newForm.Show();
            this.Hide();
        }
    }
}
